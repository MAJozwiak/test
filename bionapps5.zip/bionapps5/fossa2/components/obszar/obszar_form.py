from django import forms

from .obszar_model import Obszar


class ObszarForm(forms.ModelForm):
    class Meta:
        model = Obszar
        fields = ['kod', 'nazwa']
        widgets = {
            'kod': forms.TextInput(attrs={'class': 'form-control'}),
            'nazwa': forms.TextInput(attrs={'class': 'form-control'}),
        }