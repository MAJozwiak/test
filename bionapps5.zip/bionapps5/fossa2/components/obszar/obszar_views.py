from django.views import View
from django.shortcuts import render, redirect, get_object_or_404
from django.core.paginator import Paginator

from fossa2.config import OBSZAR_TEMPLATE
from fossa2.models import Obszar
from .obszar_form import ObszarForm


class ObszarListView(View):
    template_name = OBSZAR_TEMPLATE

    # Dodanie obszaru
    def add_obszar(self, request):
        form = ObszarForm(request.POST)
        if form.is_valid():
            obszar = form.save(commit=False)
            obszar.utworzone_przez_uzytkownika = request.user.username
            obszar.save()
        else:
            print("dodac obslugje messege dla tej samej nazwy / kod -> ze blad")
            ## ZAD MARTA

    # Usuwanie obszaru
    def delete_obszar(self, request):
        obszar_id = request.POST.get('obszar_id')
        obszar = get_object_or_404(Obszar, id=obszar_id)
        obszar.delete()

    # Filtry
    def list_obszar(self, request):
        kod_filter = request.GET.get('kod', '')
        nazwa_filter = request.GET.get('nazwa', '')
        results_per_page = int(request.GET.get('results_per_page', 25))

        obszary = Obszar.objects.all()

        if kod_filter:
            obszary = obszary.filter(kod__icontains=kod_filter)
        if nazwa_filter:
            obszary = obszary.filter(nazwa__icontains=nazwa_filter)

        paginator = Paginator(obszary, results_per_page)
        page_number = request.GET.get('page')
        page_obj = paginator.get_page(page_number)

        context = {
            'page_obj': page_obj,
            'kod_filter': kod_filter,
            'nazwa_filter': nazwa_filter,
            'results_per_page': results_per_page,
            'form': ObszarForm(),
        }
        return render(request, self.template_name, context)

    def get(self, request):
        return self.list_obszar(request)

    def post(self, request):
        success_url = request.META.get('HTTP_REFERER', request.path_info)

        if 'add_obszar' in request.POST:
            self.add_obszar(request)

        elif 'delete_obszar' in request.POST:
            self.delete_obszar(request)

        return redirect(success_url)
