## Podmiot config
PODMIOT_TEMPLATE = "fossa2/podmiot_list.html"
PODMIOT_KOD_MAX = 10
PODMIOT_NAZWA_MAX = 300
