OBSZAR_TEMPLATE = "fossa2/obszar_list.html"





