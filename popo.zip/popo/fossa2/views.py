import re
from datetime import date

from django.core.paginator import Paginator
from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from .components.grupa.grupa_model import GrupaNaglowek

from .models import Podmiot, Obszar, Podblok, Pytanie, AnkietaNaglowek, \
    Podzapytanie
from .forms import  BlokForm, PytanieForm
from .components.podmiot.podmiot_form import PodmiotForm
from .components.obszar.obszar_form import ObszarForm
from fossa2.generator import get_data_by_grupanaglowek_id, transform_dict, generuj
from django.http import JsonResponse
from fossa2.models import Blok, OkresSprawozdawczy, INFINITY_DATE
from fossa2.components.grupa_podmiotow.grupa_podmiotow_model import GrupaPodmioty

inf = date(9999, 12, 31)

def ajax_load_bloki(request):
    # Pobieramy ID obszaru z zapytania JS
    obszar_id = request.GET.get('id_obszaru')
    bloki = Blok.objects.filter(id_obszaru_id=obszar_id,data_do=inf).order_by('kod')
    print(Blok.objects)
    print(bloki)
    data = [{'id': b.id, 'kod': b.kod, 'tresc': b.tresc[:30]} for b in bloki]
    return JsonResponse(data, safe=False)

# 2. Ładowanie Podbloków na podstawie wybranego Bloku
def ajax_load_podbloki(request):
    print("xxxxxxxxxx")
    # Pobieramy ID bloku z zapytania JS
    blok_id = request.GET.get('id_bloku')
    podbloki = Podblok.objects.filter(id_bloku_id=blok_id,data_do=inf).order_by('kod')
    print(podbloki)
    data = [{'id': p.id, 'kod': p.kod, 'tresc': p.tresc[:30]} for p in podbloki]
    return JsonResponse(data, safe=False)


def ajax_load_pytania(request):
    """Widok zwracający listę pytań przypisanych do konkretnego podbloku"""
    podblok_id = request.GET.get('id_podbloku')
    pytania = Pytanie.objects.filter(id_podbloku_id=podblok_id,data_do=inf).order_by('kod')

    # Przygotowanie danych do wysłania (id do wartości select, kod do wyświetlenia)
    data = [
        {
            'id': py.id,
            'kod': py.kod,
            'tresc': py.tresc[:40] + '...' if len(py.tresc) > 40 else py.tresc
        }
        for py in pytania
    ]
    return JsonResponse(data, safe=False)

#def home(request):
#    return render(request, 'fossa2/home.html')

def podmiot_list(request):
    # Obsługa dodawania nowego podmiotu
    if request.method == 'POST' and 'add_podmiot' in request.POST:
        form = PodmiotForm(request.POST)
        if form.is_valid():
            podmiot = form.save(commit=False)
            podmiot.utworzone_przez_uzytkownika = request.user.username
            podmiot.save()
            return redirect(request.path_info)
    else:
        form = PodmiotForm()

    # Obsługa usuwania podmiotu
    if request.method == 'POST' and 'delete_podmiot' in request.POST:
        podmiot_id = request.POST.get('podmiot_id')
        podmiot = get_object_or_404(Podmiot, id=podmiot_id)
        podmiot.delete()
        return redirect(request.path_info)

    # Pobierz parametry filtrowania z żądania
    kod_filter = request.GET.get('kod', '')
    nazwa_filter = request.GET.get('nazwa', '')

    # Filtruj dane na podstawie parametrów
    podmioty = Podmiot.objects.all()
    if kod_filter:
        podmioty = podmioty.filter(kod__icontains=kod_filter)
    if nazwa_filter:
        podmioty = podmioty.filter(nazwa__icontains=nazwa_filter)

    # Pobierz liczbę wyników na stronę z żądania
    results_per_page = int(request.GET.get('results_per_page', 25))

    # Paginacja
    paginator = Paginator(podmioty, results_per_page)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    context = {
        'page_obj': page_obj,
        'kod_filter': kod_filter,
        'nazwa_filter': nazwa_filter,
        'results_per_page': results_per_page,
        'form': form,
    }

    return render(request, 'fossa2/podmiot_list.html', context)

def podblok_list(request):
    return render(request, 'fossa2/podblok_list.html')
def podzapytanie_list(request):
    return render(request, 'fossa2/podzapytanie_list.html')
def obszar_list(request):
    # Obsługa dodawania nowego obszaru
    if request.method == 'POST' and 'add_obszar' in request.POST:
        form = ObszarForm(request.POST)
        if form.is_valid():
            obszar = form.save(commit=False)
            obszar.utworzone_przez_uzytkownika = request.user.username
            obszar.save()
            return redirect(request.path_info)
    else:
        form = ObszarForm()

    # Obsługa usuwania obszaru
    if request.method == 'POST' and 'delete_obszar' in request.POST:
        obszar_id = request.POST.get('obszar_id')
        obszar = get_object_or_404(Obszar, id=obszar_id)
        obszar.delete()
        return redirect(request.path_info)

    # Pobierz parametry filtrowania z żądania
    kod_filter = request.GET.get('kod', '')
    nazwa_filter = request.GET.get('nazwa', '')

    # Filtruj dane na podstawie parametrów
    obszary = Obszar.objects.all()
    if kod_filter:
        obszary = obszary.filter(kod__icontains=kod_filter)
    if nazwa_filter:
        obszary = obszary.filter(nazwa__icontains=nazwa_filter)

    # Pobierz liczbę wyników na stronę z żądania
    results_per_page = int(request.GET.get('results_per_page', 25))

    # Paginacja
    paginator = Paginator(obszary, results_per_page)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    context = {
        'page_obj': page_obj,
        'kod_filter': kod_filter,
        'nazwa_filter': nazwa_filter,
        'results_per_page': results_per_page,
        'form': form,
    }
    return render(request, 'fossa2/obszar_list.html', context)


def blok_list(request):
    # Obsługa dodawania nowego bloku
    if request.method == 'POST' and 'add_blok' in request.POST:
        form = BlokForm(request.POST)

        if form.is_valid():
            blok = form.save(commit=False)

            obszar = blok.id_obszaru
            ostatni = obszar.bloki.all()

            if ostatni.exists():
                ostatni_kod = max(int(b.kod) for b in ostatni)
                nowy_kod = str(ostatni_kod + 1)
            else:
                nowy_kod = '1'

            blok.kod = nowy_kod

            blok.utworzone_przez_uzytkownika = request.user.username
            blok.save()
            return redirect(request.path_info)
    else:
        form = BlokForm()

    # Obsługa usuwania bloku
    if request.method == 'POST' and 'delete_blok' in request.POST:
        blok_id = request.POST.get('blok_id')
        blok = get_object_or_404(Blok, id=blok_id)
        blok.delete()
        return redirect(request.path_info)

    # Pobierz parametry filtrowania z żądania
    obszar_filter = request.GET.get('obszar', '')
    kod_filter = request.GET.get('kod', '')
    tresc_filter = request.GET.get('tresc', '')

    # Filtruj dane na podstawie parametrów
    bloki = Blok.objects.all()
    if obszar_filter:
        bloki = bloki.filter(obszar_id_obszaru__icontains=obszar_filter)
    if kod_filter:
        bloki = bloki.filter(kod__icontains=kod_filter)
    if tresc_filter:
        bloki = bloki.filter(tresc__icontains=tresc_filter)

    # Pobierz liczbę wyników na stronę z żądania
    results_per_page = int(request.GET.get('results_per_page', 25))

    # Paginacja
    paginator = Paginator(bloki, results_per_page)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    context = {
        'page_obj': page_obj,
        'obszar_filter': obszar_filter,
        'kod_filter': kod_filter,
        'tresc_filter': tresc_filter,
        'results_per_page': results_per_page,
        'form': form,
    }
    return render(request, 'fossa2/blok_list.html', context)


def pytanie_list(request):
    # pytania = Pytanie.objects.all()
    pytania = Pytanie.objects.select_related('id_bloku__id_obszaru').all()

    # Filtry
    kod_filter = request.GET.get('kod', '')
    blok_filter = request.GET.get('blok', '')
    tresc_filter = request.GET.get('tresc', '')
    obligatoryjne_filter = request.GET.get('obligatoryjne', '')
    wytyczne_filter = request.GET.get('wytyczne', '')

    if kod_filter:
        pytania = pytania.filter(kod__icontains=kod_filter)
    if blok_filter:
        pytania = pytania.filter(id_bloku__kod__icontains=blok_filter)
    if tresc_filter:
        pytania = pytania.filter(tresc__icontains=tresc_filter)
    if obligatoryjne_filter:
        pytania = pytania.filter(tresc__icontains=obligatoryjne_filter)
    if wytyczne_filter:
        pytania = pytania.filter(tresc__icontains=wytyczne_filter)

    # Pobierz liczbę wyników na stronę z żądania
    results_per_page = int(request.GET.get('results_per_page', 25))

    # Paginacja
    paginator = Paginator(pytania, results_per_page)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    # Dodawanie nowego pytania
    if request.method == 'POST':
        form = PytanieForm(request.POST)
        if form.is_valid():
            pytanie_list = form.save(commit=False)
            pytanie_list.utworzone_przez_uzytkownika = request.user.username
            pytanie_list.save()
            return redirect('pytanie_list')
    else:
        form = PytanieForm()

    bloki = Blok.objects.select_related('id_obszaru').all()

    context = {
        'page_obj': page_obj,
        'form': form,
        'kod_filter': kod_filter,
        'blok_filter': blok_filter,
        'tresc_filter': tresc_filter,
        'obligatoryjne_filter': obligatoryjne_filter,
        'wytyczne_filter': wytyczne_filter,
        'bloki': bloki,
        'results_per_page': results_per_page,
    }

    if request.method == 'POST' and 'delete_pytanie' in request.POST:
        pytanie_id = request.POST.get('pytanie_id')
        pytanie = get_object_or_404(Pytanie, id=pytanie_id)
        pytanie.delete()
        return redirect(request.path_info)

    return render(request, 'fossa2/pytanie_list.html', context)



def generowanie_formularzy(request):
    najnowszy_okres = OkresSprawozdawczy.objects.order_by('-rok').first()
    rok = najnowszy_okres.rok if najnowszy_okres else date.today().year
    poczatek_roku = date(rok, 1, 1)
    koniec_roku = date(rok, 12, 31)

    if request.method == 'POST' and 'generuj' in request.POST:
        grupanaglowek_id = request.POST.get('grupanaglowek_id')

        # Podajemy daty do Twojej funkcji - to odsieje "przeszłe" rekordy
        data = get_data_by_grupanaglowek_id(grupanaglowek_id, poczatek_roku, koniec_roku)

        podmioty = data['podmioty']
        ankiety = data['ankiety']

        for ankieta in ankiety:
            paczka_jedna_ankieta = {
                'ankiety': [ankieta],
                'podmioty': podmioty,
                'grupa_naglowek': data['grupa_naglowek']
            }
            transformed = transform_dict(paczka_jedna_ankieta)
            hierarchia = transformed['hierarchia']

            for podmiot in podmioty:
                generuj(hierarchia, podmiot, ankieta['nazwa'])

    grupanagloweks = GrupaNaglowek.objects.filter(
        data_od__lte=koniec_roku,
        data_do__gte=poczatek_roku
    )
    return render(request, 'fossa2/generowanie_formularzy.html', {'grupanagloweks': grupanagloweks})



def print_on_terminal(grupanaglowek_id):
    print(f"Wywołano foo() z ID: {grupanaglowek_id}")