from datetime import date

INFINITY_DATE = date(9999, 12, 31)