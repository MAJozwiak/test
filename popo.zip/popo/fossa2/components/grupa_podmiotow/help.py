def grupa_podmioty_list(request):
    najnowszy_okres = OkresSprawozdawczy.objects.order_by('-rok').first()
    poczatek_roku = date(najnowszy_okres.rok, 1, 1) if najnowszy_okres else date.today().replace(month=1, day=1)
    grupa_filter = request.GET.get('grupa', '')
    podmiot_filter = request.GET.get('podmiot', '')
    results_per_page = int(request.GET.get('results_per_page', 25))

    # -------- LOGIKA FORMULARZA (DODAWANIE) --------
    if request.method == 'POST' and 'add_grupa_podmioty' in request.POST:
        form = GrupaPodmiotyForm(request.POST)

        form.fields['id_grupa'].queryset = GrupaNaglowek.objects.filter(
            data_do=INFINITY_DATE,
            data_od=poczatek_roku
        )

        if form.is_valid():
            selected_podmioty = request.POST.getlist('selected_podmioty')
            grupa = form.cleaned_data['id_grupa']

            for podmiot_id in selected_podmioty:
                if not GrupaPodmioty.objects.filter(id_grupa=grupa, id_podmiotu_id=podmiot_id).exists():
                    GrupaPodmioty.objects.create(
                        id_grupa=grupa,
                        id_podmiotu_id=podmiot_id,
                        utworzone_przez_uzytkownika=request.user.username
                    )
            return redirect('grupa_podmioty_list')
    else:
        form = GrupaPodmiotyForm()
        form.fields['id_grupa'].queryset = GrupaNaglowek.objects.filter(
            data_do=INFINITY_DATE,
            data_od=poczatek_roku
        )

    grupa_podmioty_qs = GrupaPodmioty.objects.filter(id_grupa__data_od=poczatek_roku)

    if grupa_filter:
        grupa_podmioty_qs = grupa_podmioty_qs.filter(id_grupa__nazwa__icontains=grupa_filter)
    if podmiot_filter:
        grupa_podmioty_qs = grupa_podmioty_qs.filter(id_podmiotu__nazwa__icontains=podmiot_filter)

    paginator = Paginator(grupa_podmioty_qs, results_per_page)
    page_obj = paginator.get_page(request.GET.get('page'))

    podmioty = Podmiot.objects.all()

    # -------- USUWANIE --------
    if request.method == 'POST' and 'delete_grupa_podmioty' in request.POST:
        grupa_podmioty_id = request.POST.get('grupa_podmioty_id')
        GrupaPodmioty.objects.filter(id=grupa_podmioty_id).delete()
        return redirect('grupa_podmioty_list')

    context = {
        'page_obj': page_obj,
        'podmiot_filter': podmiot_filter,
        'grupa_filter': grupa_filter,
        'results_per_page': results_per_page,
        'form': form,
        'podmioty': podmioty,
        'rok_opis': najnowszy_okres.rok if najnowszy_okres else ""
    }

    return render(request, 'fossa2/grupa_podmioty_list.html', context)